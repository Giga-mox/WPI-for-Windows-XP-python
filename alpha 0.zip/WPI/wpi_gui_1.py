# -*- coding: utf-8 -*-
"""
WPI GUI Installer for Windows XP
--------------------------------
Графический установщик программ с чекбоксами и подсказками при наведении.
Совместим с Python 3.4 (Windows XP).
"""

import os
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox


# === Настройки ===
INSTALL_DIR = os.path.join(os.getcwd(), "Install")

# === Список программ ===
programs = [
    {
        "id": "7zip",
        "name": "7-Zip 19.00",
        "desc": "Архиватор с поддержкой 7z, ZIP, RAR и других форматов.",
        "file": "7zip.exe",
        "cmd": "/S",
    },
    {
        "id": "firefox",
        "name": "Mozilla Firefox ESR 52.9",
        "desc": "Последняя версия Firefox, совместимая с Windows XP.",
        "file": "firefox.exe",
        "cmd": "-ms",
    },
    {
        "id": "vlc",
        "name": "VLC Media Player 2.2.8",
        "desc": "Медиа-плеер, поддерживающий все форматы без кодеков.",
        "file": "vlc.exe",
        "cmd": "/S",
    },
    # Пример добавления своей программы:
    # {
    #     "id": "foobar",
    #     "name": "Foobar2000",
    #     "desc": "Аудиоплеер для Windows XP.",
    #     "file": "foobar2000.exe",
    #     "cmd": "/S",
    # },
]


class ToolTip:
    """Простая подсказка при наведении курсора"""
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tip_window = None
        widget.bind("<Enter>", self.show_tip)
        widget.bind("<Leave>", self.hide_tip)

    def show_tip(self, event=None):
        if self.tip_window or not self.text:
            return
        x, y, _, _ = self.widget.bbox("insert") if self.widget.bbox("insert") else (0, 0, 0, 0)
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        self.tip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry("+%d+%d" % (x, y))
        label = tk.Label(
            tw, text=self.text, justify='left',
            background="#ffffe0", relief='solid', borderwidth=1,
            font=("Tahoma", 8)
        )
        label.pack(ipadx=1)

    def hide_tip(self, event=None):
        tw = self.tip_window
        self.tip_window = None
        if tw:
            tw.destroy()


class WPIApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("WPI Setup for Windows XP")
        self.geometry("480x400")
        self.resizable(False, False)

        ttk.Label(self, text="Выберите программы для установки:",
                  font=("Tahoma", 10, "bold")).pack(pady=10)

        # Основная рамка со списком программ
        frame = ttk.Frame(self)
        frame.pack(fill=tk.BOTH, expand=True, padx=15)

        self.program_vars = {}
        for prog in programs:
            var = tk.BooleanVar()
            cb = ttk.Checkbutton(frame, text=prog["name"], variable=var)
            cb.pack(anchor="w", pady=2)
            ToolTip(cb, prog["desc"])
            self.program_vars[prog["id"]] = (var, prog)

        ttk.Button(self, text="Установить выбранные", command=self.install_selected)\
            .pack(pady=10)

        ttk.Button(self, text="Выход", command=self.quit).pack()

    def install_selected(self):
        selected = [p for pid, (var, p) in self.program_vars.items() if var.get()]
        if not selected:
            messagebox.showinfo("Информация", "Выберите хотя бы одну программу.")
            return

        if not os.path.exists(INSTALL_DIR):
            messagebox.showerror("Ошибка", "Папка 'Install' не найдена!")
            return

        for prog in selected:
            path = os.path.join(INSTALL_DIR, prog["file"])
            if not os.path.exists(path):
                messagebox.showwarning("Файл не найден", "Не найден файл:\n" + path)
                continue

            messagebox.showinfo("Установка", "Устанавливаю: " + prog["name"])
            try:
                subprocess.call('"%s" %s' % (path, prog["cmd"]), shell=True)
            except Exception as e:
                messagebox.showerror("Ошибка", str(e))

        messagebox.showinfo("Готово", "Установка завершена!")


if __name__ == "__main__":
    app = WPIApp()
    app.mainloop()
